
<?php

include $_SERVER['DOCUMENT_ROOT'].('/techHQ/modules/programs.php');

  $the_title = 'Xmetals TechHQ Section - Software';
  $the_content = <<<EOD

  <p>Softpedia Graphic Here</p>
   <p>Major Geeks Graphic Here</p>


   <h1>Graphics Applications</h1>
       <h2>Cross-Platform</h2>

   <div class="programSection">

     <ul>
         <li> $kritaIcon  $kritaHome Krita is a graphics editor is an open source graphics/illustrator program, which some users compare to
         Adobe Photoshop </li>

         <li> $gimpIcon  $gimpHome GIMP is a well known and widely used Graphics editor that some
         (not all though) compare to Photoshop</li>
       </ul>

		<br />
       <p>BOTH Krita (newer program overall), and GIMP (has been around awhile) can run on multiple platformms,
       including Linux and Windows</p>


   <h2 id="windows">Windows</h2>
   <div class="TwoColumns">
     <ul>
         <li> $xnviewIcon $xnviewHome </li>

         <li>My Favorite Image editor/so-called... Basic Image editor in Windows ...VERY powerful and well-done, program</li>
     </ul>

     <ul>
       <li> $irfanViewIcon $irfanViewHome </li>
     </ul>
   </div>
  </div>


   <h2>Linux</h2>
   <div class="ThreeColumns">
   <ul>
       <li><a href="https://www.kde.org/applications/graphics/gwenview/">Gwenview 1</a> ,
           <a href="https://www.kde.org/applications/graphics/gwenview/">Gwenview 2</a></li>

       <li><a href="http://docs.xfce.org/apps/ristretto/start">Ristretto Viewer</a></li>

       <li><a href="https://pinta-project.com/pintaproject/pinta/">Pinta</a></li>
   </ul>
    </div>



   <h1>Internet Related</h1>
   <h2>Cross-Platform</h2>

  <div class="programSection">

		  <div class="TwoColumns">
			 <ul>
			   <li> $pidginIcon $pidginHome - Instant Messaging Client </li>
			</ul>

			 <ul>
			   <li> $thunderbirdIcon $thunderbirdHome - Email Client</li>
			</ul>		  
		</div>

  </div>



   <h1>Productivity/Office Programs</h1>
     <h2>Cross Platform</h2>
         <h3>Office Suite</h3>

  <div class="programSection">
   <ul>
    <li> $libreOIcon $libreOHome </li>
  </ul>

   <h2>Windows</h2>
     <h3>PDF Readers - Adobe Acrobat Reader alternatives</h3>

     <div class="ThreeColumns">
       <ul>
         <li> $foxITIcon $foxITHome </li>
         <li> $sumPDFIcon $sumPDFHome </li>
         <li> $pdfXIcon $pdfXHome </li>
       </ul>
     </div>
  </div>

   <h1>Multimedia Programs</h1>
   <h2>Cross Platform</h2>


  <div class="programSection">

	   <h3>Audio Players</h3>

	   <ul>
			<li> $clemIcon $clemHome </li>

		   <li>Clementine is a music player and organizer that can not only play your music collection, organize your
		   collection (including downloading artist and album information from the internet, and play media from
		   various online sources</li>
	  </ul>

	   <h3 id="video-players">Video Players</h3>
		   <div class="ThreeColumns">
			   <ul>
				   <li> $mpvIcon $mpvHome </li>
				   <li> $smPlayerIcon $smPlayerHome </li>
				   <li> $vlcIcon $vlcHome </li>
			   </ul>
		   </div>


	   <h2>Linux</h2>
	   <ul>
		 <li><a href="http://audacious-media-player.org/">Audacious</a></li>
	   </ul>

	   <h2>Windows</h2>
		   <div class="TwoColumns">
			   <ul>
				   <li> $aimpIcon $aimpHome</li>
				   <li> $foobarIcon $foobarHome</li>
			   </ul>
		   </div>
  </div>


   <h1 id="security-programs">Security Programs</h1>
     <h2>Windows</h2>

     <div class="programSection">
       <h3>Anti-virus and Anti-Malware</h3>

       <div class="TwoColumns">
       <ul>
       <li>
           <img src="/techHQ/progIcons/security/AVs/1589__Avast!FreeAntivirus5_icon.png" alt="Avast Icon">
           <a href="http://www.avast.com/free-antivirus-download">Avast</a>
          </li>

          <li>
           <img src="/techHQ/progIcons/security/malware/mbam_IDI_MAIN.png" alt="Malwarebytes Antimalware Icon">
           <a href="http://www.malwarebytes.org/">Malwarebytes Anti-Malware</a>
       </li>
       </ul>
     </div>

     <ul>
       <li>
           <a href="https://www.emsisoft.com/en/software/eek/">Emsisoft Emergency Toolkit</a>
       </li>
     </ul>



       <h2>Cross Platform</h2>
         <h3>Cache/Temp File Cleaners</h3>

           <ul>
           <li><img src="/techHQ/progIcons/security/cleaners/bleachbit_1.jpg" alt="Bleachbit Icon">
           <a href="http://bleachbit.sourceforge.net/">Bleachbit</a></li>
           </ul>


           <h2>Windows</h2>
           <h3>Cache/Temp File Cleaners</h3>

             <div class="TwoColumns">
             <ul>
                 <li> $ccleanerIcon $ccleanerHome  </li>
                 <li> $CCEnhIcon $CCEnhHome A sort of &quot;database&quot; of what to clean for programs that support it
                  (To add more removable items then
                 the programs default)</li>

             </ul>
             </div>
     </div>


   <h1 id="system-tools">System Tools</h1>
   <h2>Windows</h2>

  <div class="programSection">
     <ul>
       <li><a href="https://www.partitionwizard.com/free-partition-manager.html">Minitools Partition Manager Freeware Edition</a></li>
     </ul>

       <h4>System Suite</h4>
       <div class="TwoColumns">
		   <ul>
			 <li> $glaryIcon $glaryHome </li>
			 <li> $wiseCareIcon $wiseCareHome</li>
		   </ul>
       </div>
  </div>

EOD;
?>

<?php include $_SERVER['DOCUMENT_ROOT'].("/templates/tech/baseTechSoftwareTemplate.php"); ?>
