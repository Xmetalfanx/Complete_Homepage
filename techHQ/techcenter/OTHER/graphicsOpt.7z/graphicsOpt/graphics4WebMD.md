##Optimizing Graphics for Websites
####There are three kinds of files you should consider using
    
  -	** GIFs **
 Files that have alot of straight lines and crisp shapes (logos). Also graphics files that use transparency are gifs. some programs allow you to see the size and quality of the image before you save it so you may find out saving as a JPG or a PNG would give better quality AND a smaller file-size</blockquote>
        
- **PNGs**
    This format I am not an expert on, but I just started thinking of changing some gifs over to PNG. As I just said they are an alternative to gifs that also has transparency capabilities. The downfall is alot of older browsers do not support PNG at all or are buggy at best when they do. I have a javascript on my site that redirects all old browsers (IE 4 - and NS 4 -, i believe ) to an update your browser site anyway, so i may be able to get away with it. Its not always the case, but already i have seen in small tests i have don't that PNGs are more compressed then gifs..... one major question i have is, &quot;is there animated PNGs&quot; </p>
       
- ** JPGs** 
     
  Used for Photos and complex images. One of, if not THE, most popular format on the web. (only gifs would be more common, IMHO). A downfall is there is no transparency support for them which forces you to use PNG or Gifs.


###Progressive (Jpgs) and Interlace (PNG and Gifs) images
     
These images are images that can allow the browser to download a smaller part of it, displaying the whole image in lower quality, then displaying them to the user, and downloading the rest of the image, 'bit by bit&quot; making that image a better quality. This is used commonly in larger files where the webmaster doesn't want the user to have to wait for a whole image to download, they can basically see it and a few seconds later the whole &quot;better&quot; quality image finishes appearing. Say an image takes 10 seconds to fully download... after maybe 3 seconds you will be able to see a &quot;general&quot; image and second by second the image will improve in quality until its final &quot;form&quot; is done downloading.
 
