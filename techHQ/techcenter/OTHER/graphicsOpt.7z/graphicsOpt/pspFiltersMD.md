##Paint Shop Pro Filters (v.7.x and up at least)
-  Automatic Color Balance
        
	This tool can be misused, so please check yourself with the preview window. Basically in most images, there is a general balance between red, yellow, and blue (which make up all other colors). Automatic color balance will fix those images that are imbalanced... say ones that look to have a &quot;red tint&quot; to them. Again, this MAY make an image appear worse off, so use at your own discretion. I find the default settings ideal on most images, though. 
         
	Image colors may also be adjust manually, for those who want more control. PSP may located a little deeper on the menus, but they are there and clearly marked.


 -  Contrast Correction<

     Contrast is the variation of dark and light in the image. Some images do not have a significant contrast, which can create a &quot;duller&quot; look. Correcting the contrast can help clear up some of the foreground-vs-the background. In my opinion, this should be adjusted image by image. Some images look better without an adjustment. Like the Color Correction, this also can be adjusted manually through the &quot;Histogram Adjustment&quot; Dialog Box under ** Adjust ~~~&gt; Brightness and Colors** *(In PSP 8... may be a LITTLE different in other versions)*
        

-  Clarity Adjustment

This is not one i have spent alot of time testing out. I do believe that it has to do with the brightness/contrast adjustments. This tool as PSP says can &quot; It can make hazy, foggy, or slightly out of focus images look clearer&quot; <span class="smallMainText">(PSP 8 help file under &quot;Clarity command&quot; )</span></p>
       