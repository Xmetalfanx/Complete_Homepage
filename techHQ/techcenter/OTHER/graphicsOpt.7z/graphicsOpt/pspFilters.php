<?php

  $title ='Xmetalfanx Optimization and Tweak Section - PSP - Paint Shop Pro Filters'

>
    
    $content = <<EOD

        <p class="boldTitles">Paint Shop Pro Filters (v.7.x and up at least)</p>
        <p class="header"> <strong>Automatic Color Balance</strong> </p>
        <blockquote>
          <p class="justify"> This tool can be misused, so please check yourself with the preview window. Basically in most images, there is a general balance between red, yellow, and blue (which make up all other colors). Automatic color balance will fix those images that are imbalanced... say ones that look to have a &quot;red tint&quot; to them. Again, this MAY make an image appear worse off, so use at your own discretion. I find the default settings ideal on most images, though. </p>
          <p class="justify"> Image colors may also be adjust manually, for those who want more control. PSP may located a little deeper on the menus, but they are there and clearly marked </p>
        </blockquote>
        <p class="header"> <strong>Contrast Correction</strong> </p>
        <blockquote>
          <p> Contrast is the variation of dark and light in the image. Some images do not have a significant contrast, which can create a &quot;duller&quot; look. Correcting the contrast can help clear up some of the foreground-vs-the background. In my opinion, this should be adjusted image by image. Some images look better without an adjustment. Like the Color Correction, this also can be adjusted manually through the &quot;Histogram Adjustment&quot; Dialog Box under <strong>Adjust ~~~&gt; Brightness and Colors</strong> <em>(In PSP 8... may be a LITTLE different in other versions)</em> </p>
        </blockquote>
        <p class="header"> Clarity Adjustment</p>
        <blockquote>
          <p class="justify"> This is not one i have spent alot of time testing out. I do believe that it has to do with the brightness/contrast adjustments. This tool as PSP says can &quot; It can make hazy, foggy, or slightly out of focus images look clearer&quot; <span
                class="smallMainText">(PSP 8 help file under &quot;Clarity command&quot; )</span></p>
        </blockquote>
        <br /><br />
    </div>
 
       
      