<title>Xmetalfanx's Homepage - Forcing Firefox Addons to work, manually</title>

<!-- InstanceBegin template="../../../security/securityIndex.php" codeOutsideHTMLIsLocked="false" -->

--------------------------------------

    $the_content = <<EOD
      <!-- InstanceBeginEditable name="main" -->
    <p class="header">Help, My favorite addon will not work with Firefox since version 10</p>
    <p>I have seen a few others with the same issue, and honestly, This is an old method to &quot;force addons&quot; on Firefox from years ago. </p>
    <p>I have to mention most addons are fine, and this is for those occasional addons that do not work. </p>
    <p>IN THEORY, all addons should be marked as Compatible, unless specifically marked as NOT COMPATIBLE; since version 10 of Firefox I have one of my favorite addons, 
    BarTab not work and by doing the following method, not only is BarTab installed (The developer stopped development, by the way), but also functioning a-ok.</p>
    <p>Please remember this guide was for Firefox 9 and the newly released Firefox 10 ... The Numbers of the Firefox releases change often, but the concept is still the same.</p>
    <p class="header">What you MIGHT need </p>
    <ul>
      <li><span class="boldText">Firefox 9.x portable. </span>
        <ul>
          <li>This way you can keep your Firefox 10+ installed, but also use a non-install version of Firefox 9 . The point of this is that you may not have the addon in-question backed up (say with FEBE) to a local .xpi file. This way with the portable version you can get the addon from Mozilla's site or the Addon tab itself</li>
        </ul>
      </li>
      <li><span class="boldText"><a href="http://customsoftwareconsult.com/extensions" target="_blank">FEBE</a></span>
        <ul>
          <li>(Firefox Addon to backup installed Addons in the portable Firefox (or any Firefox you have FEBE on) </li>
        </ul>
      </li>
      <li class="boldText">Archiver Program </li>
      <ul>
        <li>Example - <a href="http://www.7-zip.org/" target="_blank">7zip</a> or Winrar </li>
      </ul>
    </ul>
    <p class="header">Steps after you have a local copy of the addon's, giving you trouble </p>
    <p>Basically what your doing:</p>
    <ul>
      <li> Going from an XPI file extention to a ZIP file extention, and then extracting that zip file</li>
      <li>Extract one file (* <a href="#extraStep">maybe another step needed in some addons* - Scroll to Bottom of Page OR Click Here *</a>)</li>
      <li>Open in that file in a text editor (say Notepad) ......Go to a single line in that file and changing a small part of it.</li>
      <li>Saving the new edited file (that you saved in the step above), back to the zip file</li>
      <li>Going from ZIP back to XPI</li>
      <li>Install the now &quot;updated&quot; addon </li>
      <li>DONE'    </li>
    </ul>
    <p class="header">To get the addon, xpi file with a portable version of Firefox that the addon &quot;works&quot; (without any of these steps needed) .</p>
    <p>.. if you have a backup xpi from FEBE already on your computer you can skip this section completely</p>
    <ol>
      <li>Start Firefox Portable</li>
      <li>Download (whether it's the method is, from the addon website or the addon tab in Firefox) the addon you want to work with</li>
      <li>Install <a href="http://customsoftwareconsult.com/extensions" target="_parent">FEBE Addon</a></li>
      <li>Backup the Addons with FEBE (Firefox Addon) (There are a few ways to do it, and I may have links to show you how, later) ...bottom line is you want the addon in an .XPI formatted file
        <ol>
          <li>This is what format they are in already ... though Firefox &quot;auto-installs&quot; them (or asks you if you want to install it) for you </li>
        </ol>
      </li>
    </ol>
    <p>&nbsp;</p>
    <p class="header">Full instructions, once you have the local XPI file (Addon &quot;installer&quot; file)</p>
    <p>Steps: </p>
    <ol>
      <li><span class="boldUnderline">(Optional) Make Copy of the Original XPI file, to work on </span> </li>
      <ul>
        <li>(Optional) Make copy of addon XPI (if something goes wrong you can always backup with FEBE again) ... This is as simple as &quot;selecting&quot;/&quot;highlighting&quot; the XPI file and hitting Control + C, then Control + V </li>
        <li>I may suggested changing the addon name too ... say &quot;BarTab&quot; ... would be &quot;Edited_Bartab&quot; .. (or whatever you like) </li>
      </ul>
    </ol>
    <p class="italics">OK, whether you are now working on the copy of the XPI or the original, I am going to just say &quot;The XPI file&quot; from now on. </p>
    <ol>
      <nr />
      <br />
      <li><span class="boldUnderline">Make sure you can see the &quot;.xpi&quot; and change that to &quot;.zip&quot;
        (make sure you can see file extensions</span>
        <ul>
          <li>&quot;How the heck do I do this?&quot; ... </li>
          <li>(with file extensions showing) highlight the part of the file that says &quot;xpi&quot; at the end and change it to &quot;zip&quot; ... THATS IT
            <ul>
              <li>See? .. .nothing complicated <img src="../../../smiles/happy/happy_dance.gif" width="26" height="20" alt="happy smile" /></li>
              <br />
              <br />
            </ul>
          </li>
        </ul>
      </li>
      <li><span class="boldUnderline">Open the now ZIP file with your choice of archiving programs</span>
        <ol>
          <li>Some program are better than others, though I am not going to list archive programs here </li>
          <li>The file you want to extract (anywhere ... your desktop, &quot;my documents&quot; ... where-ever you desire) is <span class="blue">install.rdf</span></li>
        </ol>
      </li>
      <li><span class="boldUnderline">Open install.rdf with a text editor such as Notepad</span></li>
      <ul>
        <li>Look for the line <span class="code">&lt;em:maxVersion&gt;3.6.*&lt;/em:maxVersion&gt; </span>(the number may vary) </li>
        <li>Change it to a higher number.
          <ul>
            <li>(I know * works as a &quot;wildcard&quot;, though I am not sure how &quot; <span class="code">*.*.*</span> &quot; would work. If that did work, then you would never have to do this for that addon again.</li>
          </ul>
        </li>
        <li><span class="code">&lt;em:maxVersion&gt;18.*&lt;/em:maxVersion&gt;</span> is an example of the new line you typed .. just changing the number... now save the file in place
          <ul>
            <li>IF (must do, however some do not) this works with your addon, then this addon would be OK up to Firefox 18 (in theory)</li>
            <br />
            <span class="boldUnderline"><br />
            </span>
          </ul>
        </li>
      </ul>
      <li><span class="boldUnderline">Zip Add/Zip &quot;install.rdf&quot; back into the zip file and make sure it over-writes the existing &quot;install.rdf&quot; in the zip file</span>
      </li>
      <br />
      <li><span class="boldUnderline">Like in Step 2, just change the extension from &quot;zip&quot; back to &quot;xpi&quot;</span>
        <ol>
          <li>(with file extensions showing, simply rename the XPI to ZIP (THATS IT) 
            <ol>
              <li class="italics">Note: I am using caps for readability on this page ... I do not believe it matters, though I would suggest using lower cases</li>
            </ol>
          </li>
        </ol>
      </li>
      <li>Install the Addon on Firefox 10+ </li>
      <li>DONE </li>
    </ol>
    <p class="header"><a name="extraStep" id="extraStep"></a>Extra Step that may be required for some addons that still give you problems</p>
    <p>I will give 100% credit to where it is due (though I do not know (who or where) that at the moment). I read it on Ghack.net, I believe as one of the comments and I have to say this works great </p>
    <p><span class="boldItalics">The Point: </span>This is where you have done the steps above and you STILL get Firefox complaining the addon &quot;is still not compatible&quot;</p>
    <p>This is very easy to do and the first two or 3 instructions are the same as above</p>
    <p class="boldItalics">The Steps:</p>
    <ol>
      <li>Make sure you can see the &quot;.xpi&quot; and change that to &quot;.zip&quot;
        (make sure you can see file extensions
        <ul>
          <li>&quot;How the heck do I do this?&quot; ... </li>
          <li>(with file extensions showing) highlight the part of the file that says &quot;xpi&quot; at the end and change it to &quot;zip&quot; ... THATS IT
            <ul>
              <li>See? .. .nothing complicated <img src="../../../smiles/happy/happy_dance.gif" width="26" height="20" alt="happy smile" /></li>
              <br />
              <br />
            </ul>
          </li>
        </ul>
      </li>
      <li>Open the now ZIP file with your choice of archiving programs</li>
      <li>Look for a Folder called &quot;<span class="blue">META-INF</span>&quot; (or it may be <span class="blue">META_INF</span> )</li>
      <li>DELETE the folder, leaving everything else in the ZIP file intact</li>
      <li>Like in Step 2, just change the extension from &quot;zip&quot; back to &quot;xpi&quot;
        <ol>
          <li>(with file extensions showing, simply rename the XPI to ZIP (THATS IT) </li>
        </ol>
      </li>
      <li>Install the Addon on Firefox 10+ </li>
      <li>DONE    </li>
    </ol>
    </div>
 
  
