Help, My favorite addon will not work with Firefox since version 10

I have seen a few others with the same issue, and honestly, This is an old method to "force addons" on Firefox from years ago.

I have to mention most addons are fine, and this is for those occasional addons that do not work.

IN THEORY, all addons should be marked as Compatible, unless specifically marked as NOT COMPATIBLE; since version 10 of Firefox I have one of my favorite addons, BarTab not work and by doing the following method, not only is BarTab installed (The developer stopped development, by the way), but also functioning a-ok.

Please remember this guide was for Firefox 9 and the newly released Firefox 10 ... The Numbers of the Firefox releases change often, but the concept is still the same.

*What you MIGHT need*

Firefox 9.x portable.
This way you can keep your Firefox 10+ installed, but also use a non-install version of Firefox 9 . The point of this is that you may not have the addon in-question backed up (say with FEBE) to a local .xpi file. This way with the portable version you can get the addon from Mozilla's site or the Addon tab itself
FEBE
(Firefox Addon to backup installed Addons in the portable Firefox (or any Firefox you have FEBE on)
Archiver Program
Example - 7zip or Winrar
Steps after you have a local copy of the addon's, giving you trouble

Basically what your doing:

Going from an XPI file extention to a ZIP file extention, and then extracting that zip file
Extract one file (* maybe another step needed in some addons* - Scroll to Bottom of Page OR Click Here *)
Open in that file in a text editor (say Notepad) ......Go to a single line in that file and changing a small part of it.
Saving the new edited file (that you saved in the step above), back to the zip file
Going from ZIP back to XPI
Install the now "updated" addon
DONE'
To get the addon, xpi file with a portable version of Firefox that the addon "works" (without any of these steps needed) .

.. if you have a backup xpi from FEBE already on your computer you can skip this section completely

Start Firefox Portable
Download (whether it's the method is, from the addon website or the addon tab in Firefox) the addon you want to work with
Install FEBE Addon
Backup the Addons with FEBE (Firefox Addon) (There are a few ways to do it, and I may have links to show you how, later) ...bottom line is you want the addon in an .XPI formatted file
This is what format they are in already ... though Firefox "auto-installs" them (or asks you if you want to install it) for you
 

Full instructions, once you have the local XPI file (Addon "installer" file)

Steps:

(Optional) Make Copy of the Original XPI file, to work on
(Optional) Make copy of addon XPI (if something goes wrong you can always backup with FEBE again) ... This is as simple as "selecting"/"highlighting" the XPI file and hitting Control + C, then Control + V
I may suggested changing the addon name too ... say "BarTab" ... would be "Edited_Bartab" .. (or whatever you like)
OK, whether you are now working on the copy of the XPI or the original, I am going to just say "The XPI file" from now on.


Make sure you can see the ".xpi" and change that to ".zip" (make sure you can see file extensions
"How the heck do I do this?" ...
(with file extensions showing) highlight the part of the file that says "xpi" at the end and change it to "zip" ... THATS IT
See? .. .nothing complicated happy smile


Open the now ZIP file with your choice of archiving programs
Some program are better than others, though I am not going to list archive programs here
The file you want to extract (anywhere ... your desktop, "my documents" ... where-ever you desire) is install.rdf
Open install.rdf with a text editor such as Notepad
Look for the line <em:maxVersion>3.6.*</em:maxVersion> (the number may vary)
Change it to a higher number.
(I know * works as a "wildcard", though I am not sure how " *.*.* " would work. If that did work, then you would never have to do this for that addon again.
<em:maxVersion>18.*</em:maxVersion> is an example of the new line you typed .. just changing the number... now save the file in place
IF (must do, however some do not) this works with your addon, then this addon would be OK up to Firefox 18 (in theory)


Zip Add/Zip "install.rdf" back into the zip file and make sure it over-writes the existing "install.rdf" in the zip file

Like in Step 2, just change the extension from "zip" back to "xpi"
(with file extensions showing, simply rename the XPI to ZIP (THATS IT)
Note: I am using caps for readability on this page ... I do not believe it matters, though I would suggest using lower cases
Install the Addon on Firefox 10+
DONE

####Extra Step that may be required for some addons that still give you problems

I will give 100% credit to where it is due (though I do not know (who or where) that at the moment). I read it on Ghack.net, I believe as one of the comments and I have to say this works great

The Point: This is where you have done the steps above and you STILL get Firefox complaining the addon "is still not compatible"

This is very easy to do and the first two or 3 instructions are the same as above

*The Steps:*

1.	Make sure you can see the ".xpi" and change that to ".zip" (make sure you can see file extensions
	-	"How the heck do I do this?" ...
	-	(with file extensions showing) highlight the part of the file that says "xpi" at the end and change it to "zip" ... THATS IT
		-	See? .. .nothing complicated (happy smile graphic here)

2.	Open the now ZIP file with your choice of archiving programs
3.	Look for a Folder called "META-INF" (or it may be META_INF )
4.	DELETE the folder, leaving everything else in the ZIP file intact
5.	Like in Step 2, just change the extension from "zip" back to "xpi"
	-	(with file extensions showing, simply rename the XPI to ZIP (THATS IT)
6.	Install the Addon on Firefox 10+
7.	DONE