# Search for Packages

-Arch: `pacman -Ss`

-Red Hat/Fedora: `dnf search`

-Debian/Ubuntu

- `apt-cache search packageName`

- `aptitude search packagename`

-SUSE/openSUSE:

- `zypper search`

- `zypper se [-s]`

-Gentoo:
`emerge -S`

---

# Install a package(s) by name

- Arch `pacman -S`

- Red Hat / Fedora `dnf install`

- Debian / Ubuntu-based `apt-get install`

- OpenSUSE
	-	`zypper install`
	-	`zypper in`

- Gentoo `emerge [-a]`

---

# Remove a package(s) by name

- Arch

```
    
 
```

- Red Hat / Fedora `dnf remove`

- Debian / Ubuntu-based `apt-get autoremove`

- OpenSUSE

   `zypper remove`
   `zypper rm`

- Gentoo

	`emerge -C`

---

-Arch

-Red Hat/Fedora

-Debian/Ubuntu

-SUSE/openSUSE

-Gentoo
