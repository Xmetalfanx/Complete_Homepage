#Upgrading Debian Stable (What you have to start with)


*** DO THESE IN ORDER ***

---

###Update and Upgrade (Current Stable) to the newest it can be
	
2. Update the repository "database"

	`sudo apt-get update`

3. Upgrade the system

	`sudo apt-get upgrade`

4. Do a Distributuon upgrade

	`sudo apt-get distr-upgrade`

4. Now (it may not be needed, but I choose to do it) Reboot the computer
 
---
###Get ready to upgrade to "Testing"

1. Go into the Terminal and type in whats below to edit your "sourcelist"
`sudo nano /etc/apt/sources.list`

	- Once the file is opened, go to the line where it says "CD_ROM" or something to that effect and comment it out by putting a  `#`  in front of the entire line.

		- The point of this is everytime you "sudo apt-get update" (without it being commented out), it will check to see if it can find the Flashdrive/CD-Rom/..etc ... this just tells the system not to check that

2. (still in *sources.list*) You will see something similar to the following lines

```
deb http://ftp.us.debian.org/debian stable main contrib non-free
deb-src http://ftp.us.debian.org/debian stable main contrib non-free

deb http://ftp.debian.org/debian/ wheezy-updates main contrib non-free
deb-src http://ftp.debian.org/debian/ wheezy-updates main contrib non-free

deb http://security.debian.org/ wheezy/updates main contrib non-free
deb-src http://security.debian.org/ wheezy/updates main contrib non-free
```
*Yours may only have "main" listed (look toward the end of each line, above) ... same process though*

STEP 1 : ADJUST THE SOURCES.LIST file to the new branch

(if you only have **MAIN** listed at the end, you may want to add **contrib**... and **non-free**

- IF YOUR UPGRADING, to "Whatever is in the testing branch"

	Where you see ++Wheezy++ , change that to   to ++Testing++ 

- IF YOUR UPGRADING TO (whats currently the testing branch when I am typing this) Jessie
	
   	The difference is if you upgrade to Jessie, when Jessie becomes the Stable Branch in the future,unlike the step above where you will always be (unless you change something) using the Testing Branch ... Here you will be using the Stable Debian branch one "Jessie becomes stable" 

		Yes I know that can sound confusing 

Change where you see Wheezy .... to Jessie ''

Step 2: **Update the repository "database" **

`sudo apt-get update`

Step 3: ** Upgrade the system**

`sudo apt-get upgrade`

Step 4: **Do a Distributuon upgrade**

`sudo apt-get distr-upgrade`

Now (it may not be needed, but I choose to do it) Reboot the computer
If nothing went wrong, You are now done ... You are now on Debian "Testing"/"Wheezy" depending on what you picked.