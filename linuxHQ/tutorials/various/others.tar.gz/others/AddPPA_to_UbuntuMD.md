#PPA's 

A PPA = A "repository" or "repo" (for short)

*I do not take any responsibility if you break

[TOC]


##Introduction

A PPA is a way to add even more sources to your package manager database. Though some PPAs may not be trust-worthy, and although I do agree that if you add too many or "the wrong ones" your system may become unstable. (No worse than what I have seen out of a typical Microsoft Windows install)

Most PPA's I use are trustworthy and programs like apt-get, aptitude (both terminal based), or even software centers and Synaptic Package Manager all check dependencies so that adding a piece of software from a new repo, it will not break your system. I can not claim that if you add every single piece of software from every repo I have listed, that your system will be stable, though I would never suggest anything that may harm anyone's system.

##Adding a PPA syntax:
```
sudo add-apt-repository ppa:user/ppa-name
sudo apt-get update
```
the ppa: (whatever) part is given to you, and changes with each PPA 


---


##COMPLETE LIST OF PPAS that I add (All in one )

- Noobslab Theme PPA 
- Noobslab Icons (1 and 2) PPA
- Noobslab Apps (1 and 2) PPA 
- Webup8 Team's PPA
- Grub Customizer 
- Libre Office's PPA ( for NEWEST versions that may not be in repos)
- PPA for adding (at least in some) The Linux Mint Update Manager on other Ubuntu based distros 

With Auto-Confirmation
```
sudo add-apt-repository -y ppa:noobslab/themes && sudo add-apt-repository -y ppa:noobslab/icons && sudo add-apt-repository -y ppa:noobslab/icons2 && sudo add-apt-repository -y ppa:noobslab/apps && sudo add-apt-repository -y ppa:noobslab/apps2 && sudo add-apt-repository -y ppa:nilarimogard/webupd8 && sudo add-apt-repository -y ppa:danielrichter2007/grub-customizer && sudo add-apt-repository -y ppa:libreoffice/ppa && sudo add-apt-repository -y ppa:ferramroberto/lffl
```

Without auto-comfirmation
```
sudo add-apt-repository ppa:noobslab/themes && sudo add-apt-repository ppa:noobslab/icons && sudo add-apt-repository ppa:noobslab/icons2 && sudo add-apt-repository ppa:noobslab/apps && sudo add-apt-repository ppa:noobslab/apps2 && sudo add-apt-repository ppa:nilarimogard/webupd8 && sudo add-apt-repository ppa:danielrichter2007/grub-customizer && sudo add-apt-repository ppa:libreoffice/ppa && sudo add-apt-repository ppa:ferramroberto/lffl
```

---
###Linux Mint Update Manager on other Ubuntu based distrobutions
- sudo add-apt-repository ppa:ferramroberto/lffl
- sudo apt-get update
- sudo apt-get install mintupdate synaptic

---

#Popular App's PPA's
## OFFICE SUITES 

###Install WPS OIffice 

#####For 32bit OS
Terminal Commands:
1.	cd && wget -O wps-office.deb http://kdl.cc.ksosoft.com/wps-community/download/a18/wps-office_9.1.0.4953~a18_i386.deb
2.	sudo dpkg -i wps-office.deb
3.	sudo apt-get -f install && rm wps-office.deb
4.	wget -O web-office-fonts.deb http://kdl.cc.ksosoft.com/wps-community/download/a15/wps-office-fonts_1.0_all.deb
5.	sudo dpkg -i web-office-fonts.deb

#####For 64bit OS
Terminal Commands:
1.	cd && wget -O wps-office.deb http://kdl.cc.ksosoft.com/wps-community/download/a18/wps-office_9.1.0.4953~a18_amd64.deb
2.	sudo dpkg -i wps-office.deb
3.	sudo apt-get -f install && rm wps-office.deb
4.	wget -O web-office-fonts.deb http://kdl.cc.ksosoft.com/wps-community/download/a15/wps-office-fonts_1.0_all.deb
5.	sudo dpkg -i web-office-fonts.deb


###  Libre Office PPA for latest version

	sudo add-apt-repository ppa:libreoffice/ppa


---
##Web Browsers
###Google Chrome
*For distros based on Ubuntu 14.04 / 13.10 / 13.04 / 12.10 / 12.04* 

1. Get the Keyring
```
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
```
2. After installing the key, add it to the repository.
```
sudo sh -c 'echo "deb http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google-chrome.list'
```

3. Update the repo list
```
sudo apt-get update
```

4. (A) To install the current STABLE version
```
sudo apt-get install google-chrome-stable
```

4. (B)To install the current BETA version 
```
sudo apt-get install google-chrome-beta
```
4. (C)To install the current UNSTABLE (just a label) version
sudo apt-get install google-chrome-unstable


---


##Desktop Envirnoment PPA's 
* PLEASE BE VERY CAREFUL WHEN ADDING THESE PPAS ... THESE (IN MY OPINION) ARE THE ONES MOST LIKELY TO BREAK YOUR SYSTEM

- #### Ubuntu Mate
	    sudo add-apt-repository ppa:ubuntu-mate-dev/ppa
    	
    	-	For Trusty based systems 
    		sudo add-apt-repository ppa:ubuntu-mate-dev/trusty-mate

		-	For Vivid based Systems 
			sudo add-apt-repository ppa:ubuntu-mate-dev/vivid-mate

- ####Cinnamon
*Not sure if this one really works well on some distros *
```
sudo add-apt-repository ppa:tsvetko.tsvetkov/cinnamon
```
**This is the Cinnamon PPA (below), I recently added to Ubuntu based distros (that are not Linux Mint)

 ```
	sudo add-apt-repository ppa:gwendal-lebihan-dev/cinnamon-nightly 
```


- #####Gnome 3
*Use with caution.. I really do not remember, using this, but thats not saying its bad ... i just don't remember this

    ```
    sudo add-apt-repository ppa:webupd8team/gnome3
    ```

# [Click here to get more PPAs](http://xmetal.x10.mx/linuxHQ/tutorials/MorePPAsMD.html)