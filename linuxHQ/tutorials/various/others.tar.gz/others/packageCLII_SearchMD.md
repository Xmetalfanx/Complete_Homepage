# Search for Packages

- ## Ubunutu/Debian
  - sudo apt-get search *package name*
  - sudo aptitude search *package name*


- ## OpenSuse
  - sudo zypper search *package name*


- ## Fedora
    ### 23 and beyond
    - sudo dnf search *package name*

    ### 22 and earlier
    - sudo yum search *package name*

## Arch-based
  - ### Including Apricity, Antergos, and Manjaro
    - sudo pacman -Ss *package name*
