# Search for Packages

- ## Ubunutu/Debian
  - sudo apt-get install *package name*
  - sudo aptitude install *package name*


- ## OpenSuse
  - sudo zypper install *package name*


- ## Fedora
    ### 23 and beyond
    - sudo dnf install *package name*

    ### 22 and earlier
    - sudo yum install *package name*

## Arch-based
  - ### Including Apricity, Antergos, and Manjaro
    - sudo pacman -Ss *package name*
