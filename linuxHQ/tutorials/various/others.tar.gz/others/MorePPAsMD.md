## More PPAs 


- #####Streaming audio recorder - Can record streaming audio
```
sudo apt-add-repository ppa:osmoma/audio-recorder
```
- #####Installing a few tweak tools for Ubuntu/Unity
```
sudo apt-get install unsesttings unity-tweak-tool
```

- #####Grub Customizer PPA
```
sudo add-apt-repository ppa:danielrichter2007/grub-customizer
```

-  **Webmin on Ubuntu 14.04**

	Useful "app" I found years ago that lets you manage many different parts of your system all in one place
```
	1. sudo echo "deb http://download.webmin.com/download/repository sarge contrib" >> /etc/apt/sources.list
	2. wget -q http://www.webmin.com/jcameron-key.asc -O- | sudo apt-key add -
	# OpenSuse Repo Key
	3. sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 977C43A8BA684223
	4. sudo apt-get update
	5. sudo apt-get install webmin
```

![User Admin Screenshot](http://www.webmin.com/screens2/useradmin.png)
![Firewall Rule Creation](http://www.webmin.com/screens2/firewall-edit.png)




- ##### Deepin Linux PPA - With the Deepin Software Center
```
sudo add-apt-repository ppa:noobslab/deepin-sc
  ```

-  ##### Audio Recorder - Streaming audio recorder
```
sudo apt-add-repository ppa:osmoma/audio-recorder
```
	- ![Audio Recorder Screenshot](https://lh4.googleusercontent.com/-DczIitaxSTk/UsVcAZeRZwI/AAAAAAAAG4I/zXawPGLNdwU/s1600/audio-recorder-2.jpg)

- ##### Y PPA Manager - Search, Purge, and Manage PPA's 
```
sudo add-apt-repository ppa:webupd8team/y-ppa-manager
```
- ##### Kodi Related
```
sudo add-apt-repository ppa:team-xbmc/ppa 
```
	- *How to install kodi*
    ```
    sudo apt-get install kodi kodi-pvr* kodi-audioencoder* 
    ```



- ##### Some Indicators for Ubuntu's Unity and other items
```
sudo add-apt-repository ppa:diesch/testing  
```