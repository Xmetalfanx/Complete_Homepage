<div id="col1">
	<div class="familyHeader">Desktops <br />Environments </div>
	<div class="family">
		<a href="/linuxHQ/desktops/budgie.php">Budgie-Desktop</a><br />
		<a href="/linuxHQ/desktops/cinnamon.php">Cinnamon</a><br />
		<a href="/linuxHQ/desktops/KDE.php">KDE</a><br />
		<a href="#">LXDE</a><br />
		<a href="/linuxHQ/desktops/mate.php">Mate</a><br />
		
		<a href="#">Openbox</a><br />
		<a href="#"></a><br />
		<a href="#"></a><br />



		<a href="/linuxHQ/newUserHQ/DesktopE.php">Desktop Environment FAQs</a><br />
		<a href="/linuxHQ/newUserHQ/myRecommendedDistros.php">My Recommended Distros (Opinion) </a>
	</div>

</div>
