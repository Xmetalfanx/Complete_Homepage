<div id="col1">
	<div class="familyHeader">Desktops </div>
	<div class="family">
		<a href="/linuxHQ/desktops/budgie.php">Budgie-Desktop</a><br />
		<a href="/linuxHQ/desktops/cinnamon.php">Cinnamon</a><br />
		Gnome-shell <br />
		<a href="/linuxHQ/desktops/KDE.php">KDE</a><br />
		<a href="/linuxHQ/desktops/mate.php">Mate</a><br />
		<a href="/linuxHQ/desktops/openbox.php">Openbox</a><br />
		<a href="/linuxHQ/desktops/LXDE.php">LXDE</a><br />
		<a href="/linuxHQ/desktops/XFCE.php">XFCE</a><br />
		<a href="#"></a><br />



		<a href="/linuxHQ/newUserHQ/DesktopE.php">Desktop Environment FAQs</a><br />
		<a href="/linuxHQ/newUserHQ/myRecommendedDistros.php">My Recommended Distros (Opinion) </a>
	</div>

</div>
