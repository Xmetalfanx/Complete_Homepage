<div id="col2">
	<div class="icon">
	    <?php echo $icon; ?>
	</div>

  	<div class="distroTitle">
	   <?php echo $name; ?>
	</div>

   <div id="distroTables" style="clear:both;">
    	<div class="infoLeft">
	    <div class="distroHeader">Homepage: </div>
		<?php echo $homepage; ?> <br />

         <div class="distroHeader">Distro "Family":</div>
				<?php echo $family; ?>

	    <div class="distroHeader">Forums:</div>
				<?php echo $forum; ?>

	    <div class="distroHeader">Destop Options:</div>
		<?php echo $DE; ?>
		
		<div class="distroHeader">Xmetal's Youtube's Review Playlist:</div>
				<?php echo $YTPlaylist; ?>
          
          
          <div class="distroHeader">Software Based:</div>
			<?php echo $software; ?>



       </div>

        <div class="infoRight">
           <div class="distroHeader"> Lastest Version: </div>
          	<?php echo $version; ?><br />

            <div class="distroHeader">Download:</div>
          	<?php echo $download; ?> <br />

           <div class="distroHeader">Distrowatch Link: </div>
      		<?php echo $distroWatch; ?>



			<div class="distroHeader">Targeted User:</div>
				<?php echo $target; ?>

			<div class="distroHeader">Tweaks/Fixes/...etc Video: </div>
				<?php echo $TweakPL; ?>
   </div>
			
			
			
			
      </div>
      
      <div id="descript" style="clear:both;" >
		<div class="distRevTitle"> Similar Distros </div>
			<?php echo $similar; ?>
	  </div>
	
	
	<br />

       <div id="descript">
			<div class="distRevTitle">Description:</div>		
				<?php echo $description; ?>
      </div>

    <div class="bold">Screenshots  </div>
    <div id="distroShots">

		<?php echo $distroSshot; ?> 
	</div> <br />
     
    <div style="clear:both; margin-top: 15px;" class="distRevTitle">Reviews</div>
				<?php include $_SERVER['DOCUMENT_ROOT'].('/linuxHQ/modules/linuxDistroReviewer.php'); ?>

    <div id="personalExp">
        <div class="distRevTitle">My Experience: </div>
		<?php echo $EXP; ?> <br />
		<?php echo $experience; ?> <br /><br />


        <span class="bold">Would I recommend this distro to a new user (to Linux)  (Yes/No) ? </span>:
	   <?php echo $newbRecommend; ?> <br /> <br />
		<blockquote>
		  <?php echo $recComments; ?>
		</blockquote>
              <br />

      <span class="bold">Would I recommend this distro (Yes/No) ?</span>:
		<?php echo $recommend; ?> <br />


      <blockquote>
		<?php echo $recComments; ?>
      </blockquote>
	  <br /> <br />
	  
    <span class="boldUnderline" style="clear: both">Any other comments I have about this distro: </span>
	<?php echo $otherComments; ?>
   </div>

   <div id="personalExp">
	   <div class="distRevTitle"> USB Drive Creation Experience </div>
	   <br />
	   <?php include $_SERVER['DOCUMENT_ROOT'].('/linuxHQ/modules/usb.php'); ?>
   
   </div>

</div> <!-- End Col2 -->
