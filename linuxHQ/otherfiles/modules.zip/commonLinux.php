<?php 
		
    function iconIMG($src, $alt)
    {
      echo "<img src= \"/linuxHQ/graphics/icons/" . $src . ".png\" alt=\" " . $alt . "\" > ";
    }
		
		function valIcon($src, $altTag)
		{
				echo "<img src=\" " . $src . "\" alt=\" " . $altTag . "\" width=\"88\" height=\"31\" class=\"right\" >" ;
		}
?>		
