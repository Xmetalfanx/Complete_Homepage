<?php
	// Start Arch Based Distros
	
	
	
	$antergos = '<a href="/linuxHQ/distros/arch/antergos.php" >Antergos<a>
		     <a href="http://www.antergos.com" target="_blank">Antergos Homepage</a>';

	$manjaro = '<a href="/linuxHQ/distros/arch/manjaro.php" >Manjaro<a>
		     <a href="http://www.manjaro.com" target="_blank">Manjaro Homepage</a>';

	$manjaroMM = '<a href="/linuxHQ/distros/arch/mmManjaro.php" >Manjaro by MM<a>
		     <a href="http://www.manjaro.com" target="_blank">Manjaro by MM Homepage</a>';

	$arch = '<a href="/linuxHQ/distros/arch/mmManjaro.php" >Arch Linux <a>
		     <a href="http://www.manjaro.com" target="_blank">Manjaro by MM Homepage</a>';
	
	
	// End Arch Based


	// Start Ubuntu Based 
	$mint = '<a href="/linuxHQ/distros/ubuntu/linuxMint.php" >Linux Mint<a>
		     <a href="http://www.linuxmint.com" target="_blank">Linux Mint Homepage</a>';

	$deepin = '<a href="/linuxHQ/distros/ubuntu/deepin.php" >Deepin<a>
		     <a href="http://www.deepin.com" target="_blank">Deepin Homepage</a>';

	$ubuntu = '<a href="/linuxHQ/distros/ubuntu/ubuntu.php" >Ubuntu<a>
		     <a href="http://www.ubuntu.com" target="_blank">Ubuntu Homepage</a>';

	// End of Ubuntu Based 

	// RPM Based 
	$suse = '<a href="/linuxHQ/distros/rpm/suse.php" > Open Suse <a>
		     <a href="http://www.opensuse.com" target="_blank">OpenSuse Homepage</a>';

	$fedora = '<a href="/linuxHQ/distros/rpm/fedora.php" > Fedora <a>
		     <a href="http://www.fedora.com" target="_blank">Fedora Homepage</a>';
	
?>
