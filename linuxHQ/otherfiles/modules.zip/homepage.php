<?php

  $ubuntuHP = '<a href="/linuxHQ/distros/ubuntu/ubuntu.php" > Ubuntu </a>';
  $ubuntuMateHP = '<a href="https://ubuntu-mate.org/">Ubuntu Mate</a>';
  $kubuntuHP = '<a href="/linuxHQ/distros/ubuntu/kubuntu.php" > Kubuntu </a>';
  
  $mintHP = '<a href="/linuxHQ/distros/ubuntu/linuxMint.php"> Mint </a> (<a href="http://www.linuxmint.com" target="_blank"> Linux Mint Homepage</a>)';
  $eOSHP = '/linuxHQ/distros/ubuntu/elementaryOS.php';
  $linuxLiteHP = '/linuxHQ/distros/ubuntu/linuxLite.php';

  $fedoraHP = '<a href="/linuxHQ/distros/rpm/fedora.php"> Fedora </a> (<a href="https://fedoraproject.org/">The Fedora Project  Homepage</a>)';
  $kororaHP = '<a href="/linuxHQ/distros/rpm/korora.php"> Korora </a>';

  $suseHP = '<a href="/linuxHQ/distros/rpm/openSuse.php"> OpenSuse </a> (<a href="https://www.opensuse.org/" target-"_blank">OpenSuse\'s Homepage</a>)';


?>
