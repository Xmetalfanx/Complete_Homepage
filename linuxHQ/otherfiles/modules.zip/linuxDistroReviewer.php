<?php

    	  // Mathew  Moore
         $mm = '<a href="https://www.youtube.com/user/MrGizmo757" target="_blank">Matthew Moore\'s Youtube Homepage</a>';

        //Linux4UandMe
        $kaddy = '<a href="https://www.youtube.com/user/Linux4UnMe" target="_blank">Linux4UnMe\'s Youtube Homepage</a>  ';

        // Spatry
        $spatry = '<a href="https://www.youtube.com/user/LinuxSpatry" target="_blank">Spatry\'s Youtube Homepage</a>';

        //DasGregor
        $dasGregor = '<a href="https://www.youtube.com/user/DasGregor" target="_blank">DasGregor\'s Youtube Homepage</a>';

        // Jeff Linux Turner
        $JLT = '<a href="https://www.youtube.com/user/0658james" target="_blank">Jeff Linux Turner\'s Youtube Hompage</a>';

        // quidsup
        $quidsup = '<a href="https://www.youtube.com/user/quidsup" target="_blank">quidsup\'s Youtube Homepage</a>';

        // InfinitelyGalactic
        $IG = '<a href="https://www.youtube.com/user/InfinitelyGalactic" target="_blank">InfinitelyGalactic\'s Youtube Homepage</a> ';

        // tostoday
        $tos = '<a href="https://www.youtube.com/user/tostoday" target="_blank">Tostoday\'s Youtube Homepage</a>';

        // midfingr
        $midfingr = '<a href="https://www.youtube.com/user/midfingr" target="_blank">midfingr\'s Youtube Homepage</a> ';

        // OhHeyItsLou
        $OhHeyItsLou = '<a href="https://www.youtube.com/user/OhHeyItsLou">OhHeyItsLou\'s Youtube Homepage</a>';

        //Run Level Zero
        $RLZ = '<a href="https://www.youtube.com/user/runlevelzer0" target="_blank">Run Level Zer0\'s Youtube Homepage</a>';

        // UrAvgLinuxUser =
        $UrAvgLinuxUser = '<a href="https://www.youtube.com/user/UrAvgLinuxUser" target="_blank">UrAvgLinuxUser\'s Youtube Homepage</a>';

		// JB
		$JB = '<a href="https://www.youtube.com/user/jupiterbroadcasting" target="_blank">Jupiter Broadcasting\'s  Youtube  Homepage</a>';

		$AJ = '<a href="https://www.youtube.com/user/freedomredux"  target="_blank">   AJ Reissig\'s  Youtube Homepage </a> ';

		$CH = ' <a href="https://www.youtube.com/user/microfreaks1"  target="_blank"  >  Charlie Henson\'s Homepage </a> ';

    $LHG = '<a href="https://www.youtube.com/channel/UCZJGcgeKADhL0uVscQ25Sxg" target="_blank"> Linux Help Guy\'s Homepage </a>' ;
    
    $FLL = '<a href="https://www.youtube.com/channel/UCV3xEKiVBnVe_v5pSZ-iwlA" target="_blank"> Fishman Love Linux </a> ';

?>

<div style="border: 1px solid #000000; padding-bottom: 10px; padding-left: 10px; line-height: 20px; clear: both; overflow: auto;">
<div class="left" style="float: left; width: 40%;">
		Mathew  Moore -	<?php echo $mm; ?>	<br />
		Linux4UandMe -  <?php echo $kaddy; ?>  <br />
		Spatry - <?php echo $spatry; ?><br />	
		DasGregor -<?php echo $dasGregor; ?>  <br />
		Jeff Linux Turner -	<?php echo $JLT; ?>	<br />
      	quidsup  	-   	<?php echo $quidsup; ?> <br />
      	InfinitelyGalactic -    <?php echo $IG; ?>   	<br />
      	tostoday  - <?php echo $tos; ?>    	<br />
  Fishman Loves Linux =     <?php echo $FLL; ?>      <br />
 </div>
 <div class="right" style="width: 40%;">
        midfingr - <?php echo $midfingr; ?>     <br />
      	OhHeyItsLou  - <?php echo $OhHeyItsLou; ?>	<br />
      	Run Level Zero -  	<?php echo $RLZ; ?>   	<br />
        UrAvgLinuxUser - <?php echo $UrAvgLinuxUser; ?>   <br />
        Jupitor Broadcasting  -  <?php echo $JB; ?> <br />
        AJ Reissig -    <?php echo $AJ; ?>        <br />
        Charlie Henson -  <?php echo $CH; ?>        <br />
        Linux Help Guy -        <?php echo $LHG; ?>        <br />
       
	</div>

</div>
