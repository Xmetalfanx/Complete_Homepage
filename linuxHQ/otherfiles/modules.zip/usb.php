<p>
	<a href="/linuxHQ/info.php" target="_blank">Explaination of what this section is</a>
</p>
	
	<table border="1">
	<caption><span class="bold">USB Creation Experience - Windows</span></caption> 
		<tr>
		  <td class="boldItalics" width="20%">imageUSB</td>
		  <td></td>
		  <td class="boldItalics" width="20%">YUMI</td>
		  <td></td>
		  <td class="boldItalics" width="20%">Unetbootin</td>
		  <td></td>
	</table>
	
<table border="1" style="margin-top: 20px">
	<caption>
			<span class="bold">USB Creation Experience - Linux</span>
	</caption> 
		<tr>
		  <td class="boldItalics" width="20%">dd command</td>
		  <td></td>
		  <td class="boldItalics" width="20%">Linux Mint USB Creator</td>
		  <td></td>
	</table>
