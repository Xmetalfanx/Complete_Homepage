 <div id="col1">
    <div class="familyHeader">Overall</div>
      <span class="family">How to Update any Linux System</span>

    <div class="familyHeader">Arch Based</div>
	    <span class="family">Adding AUR Support Optimizing Download Mirrors<br />
	                        (Manjaro or Arch)</span>
      
    <div class="familyHeader">Debian based</div>
      <span class="family">
         <a href="http://debgen.simplylinux.ch/" target="_blank">Source List Generator</a><br />
         <a href="https://sites.google.com/site/mydebiansourceslist" target="_blank">Additional Sources</a><br />
         <br />
      
	       <a href="upgradingDebianBranches.php">Upgrading Debian Branches</a><br />
	       <a href="upgradingFromDebianStable.php">Upgrading from Stable Branch</a><br />
	       <br />
	        Adding PPA support to Debian<br />	(thanks to "Linux4UandMe")
      </span>
      
      
    <div class="familyHeader">Ubuntu based</div>
		  <span class="family">
			  <a href="AddPPA_to_Ubuntu.php">Adding PPAs/What is a PPA/<br />
					List of common PPAs</a><br />"Dirty" Upgrading</span>
  </div>
 
