<?php 
  // Variables 
     $distroIcon = '<img src=" ' . $display[icons] . ' " alt=" ' . $display[distroName] . ' \'s Homepage" />';
    
     $homepage = '<a href=" ' . $display[homepage] . ' " > '  . $display[distroName] . ' \'s Icon " > ';
    
     $forum = '<a href=" ' . $display[forum] . ' " > '  . $display[distroName] . ' \'s Forum " > ';
        
     $ytReview = '<a href=" ' . $display[ytplaylist] . ' " > '  . $display[distroName] . ' \'s Youtube Review Playlist \" > ';
    
     $download = '<a href=" ' . $display[download] .  ' " > '  . $display[distroName] . ' \'s Downloads \" > ';
        
     $distroWatch = '<a href=" ' . $display[distroWatch] . ' " > '  . $display[distroName] . ' \'s Distrowatch Page" > ';
    
    $tweakPL = '<a href=" ' . $display[tweakPL] . ' " > '  . $display[distroName] . ' \'s Youtube Tweak Playlist \" > ';
       
  ?>