<?php

	// Mint Screenshots
	$mintBudgie1 = '	<a href="/linuxHQ/screenshots/ubuntubased/MintBudgie1.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/MintBudgie1.jpg" />
					<div style="clear:both">Budgie Desktop on Linux Mint 1 </div></a>';

	$mintBudgie2 =  '<a href="/linuxHQ/screenshots/ubuntubased/MintBudgie2.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/MintBudgie2.jpg" />
			<div style="clear:both">Budgie Desktop on Linux Mint 2</div></a>';

	$mintCin1 = '
			<a href="/linuxHQ/screenshots/ubuntubased/mint.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/mint.jpg" /></a>';

	$mintMate1 = '
			<a href="/linuxHQ/screenshots/ubuntubased/mintMate1.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/mintMate1.jpg" />
				<div style="clear:both">My Custom Mint Mate 1 </div>
				</a>';

	$mintMate2 = '
			<a href="/linuxHQ/screenshots/ubuntubased/mintMate2.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/mintMate2.jpg" />
				<div style="clear:both">My Custom Mint Mate 2 </div>
				</a>';

$mintMateOff = '
			<a href="/linuxHQ/screenshots/ubuntubased/mintMateOffical.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/mintMateOffical_small.jpg" />
				<div style="clear:both">My Custom Mint Mate 2 </div>
				</a>';
	
	$debianSShot1 = '<a href="/linuxHQ/screenshots/debian/debian.jpg">
					<img src="/linuxHQ/screenshots/debian/debian-small.jpg" />
					</a> ';

	$ubuntuSShot1 = ' <a href="/linuxHQ/screenshots/ubuntu/ubuntu.jpg">
					<img src="/linuxHQ/screenshots/ubuntu/ubuntu.jpg" />
					</a>  ';

	$eosSShot1 = '<a href="/linuxHQ/screenshots/ubuntubased/elementary.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/elementary.jpg" />
					<div style="clear:both">elementaryOS</div>
					</a> ';

	$lxleSShot1 = '<a href="/linuxHQ/screenshots/ubuntubased/lxle.jpg">
					<img src="/linuxHQ/screenshots/ubuntubased/lxle-small.jpg" />
					<div style="clear:both">
					LXLE 14.04
					</div>
					</a> ';

	$zorinSShot1 = ' <a href="/linuxHQ/screenshots/ubuntubased/zorin.jpg">
      <img src="/linuxHQ/screenshots/ubuntubased/zorin-small.jpg" />
      </a> ';

      	$deepinSShot1 = ' <a href="/linuxHQ/screenshots/ubuntubased/deepin.jpg">
      <img src="/linuxHQ/screenshots/ubuntubased/deepin-small.jpg" />
      </a> ';

      $fedoraCinn1 = ' <a href="/linuxHQ/screenshots/rpm/FedoraCinn1.jpg">
      <img src="/linuxHQ/screenshots/rpm/FedoraCinn1.jpg" />
		<div style="clear:both"> My install of Fedora, running Cinnamon </div>
		</a> ';

	$antergosKDE1 = '<a href="/linuxHQ/screenshots/archbased/antergosKDE1.jpg">
      <img src="/linuxHQ/screenshots/archbased/antergosKDE1.jpg" />
      <div style="clear:both">Antergos KDE </div>
      </a>';

     $manjaroKDE5 = '<a href="/linuxHQ/screenshots/archbased/manjaro-090p1-kde.jpg">
			<img src="/linuxHQ/screenshots/archbased/manjaro-090p1-kde_small.jpg" />
			<div style="clear:both"> Manjaro Plasma 5 KDE</div> </a>		  ';

      $manjaroXFCE1 = '<a href="/linuxHQ/screenshots/archbased/manjaro-090p1-xfce.jpg">
				<img src="/linuxHQ/screenshots/archbased/manjaro-090p1-xfce.jpg" />
				<div style="clear:both"> Manjaro XFCE </div>
      </a> ';


     $pclosKDE1 = '   <a href="/linuxHQ/screenshots/rpm/pclinuxosKDE1.jpg">
      <img src="/linuxHQ/screenshots/rpm/pclinuxosKDE1-small.jpg" /> 
      <div style="clear:both"> PCLinuxOS KDE </div>
      </a>    ';

     $suseKDE1 = ' <a href="/linuxHQ/screenshots/rpm/suseKDE1.jpg">
      <img src="/linuxHQ/screenshots/rpm/suseKDE1-small.jpg" />  
			<div style="clear:both"> OpenSuse KDE </div>
      </a>         ';
      
      $kaosKDE1 = ' <a href="/linuxHQ/screenshots/kasoKDE1.jpg">
      <img src="/linuxHQ/screenshots/kaosKDE1-small.jpg" />  
						<div style="clear:both"> KaOS KDE </div>
      </a>   ';
      
?>
