<div id="col1">
	<div class="familyHeader">FAQ's </div>
	<div class="family">
		<a href="/linuxHQ/newUserHQ/WhatIsLinux.php">What is Linux?</a><br />
		<a href="/linuxHQ/newUserHQ/liveVersion.php">What is a "Live Version"?</a><br />
		<a href="/linuxHQ/newUserHQ/partitions.php">Partitions Explained</a><br />
		<a href="/linuxHQ/newUserHQ/commonTerms.php">Common Terms, in Linux </a><br />
		<a href="/linuxHQ/newUserHQ/familiarSoftware.php">Familiar Software </a><br />
					What is a "Rolling Release"?<br />
					Linux "Myths" / <br />
					Misconceptions <br />
					What does LTS mean?<br />
		<a href="/linuxHQ/newUserHQ/DesktopE.php">Desktop Environment FAQs</a><br />
		<a href="/linuxHQ/newUserHQ/myRecommendedDistros.php">My Recommended Distros (Opinion) </a>
	</div>


	<div class="familyHeader"> Linux vs Windows </div>
	<div class="family">
		<a href="/linuxHQ/newUserHQ/LinuxVsWindows.php">MS Windows vs Linux - Pros and Cons </a><br />
 		<a href="/linuxHQ/newUserHQ/linuxPros.php">Linux Pros </a><br />
		<a href="/linuxHQ/newUserHQ/linuxCons.php">Linux Cons </a>
	</div>
	<div class="familyHeader">Tutorials </div>

</div>
