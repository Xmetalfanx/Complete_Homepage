/* Script removed by snapshot save */
